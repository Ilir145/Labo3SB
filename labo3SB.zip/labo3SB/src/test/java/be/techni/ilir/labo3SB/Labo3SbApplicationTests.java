package be.techni.ilir.labo3SB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Labo3SbApplicationTests {

	@Test
	void contextLoads() {
	}

}
