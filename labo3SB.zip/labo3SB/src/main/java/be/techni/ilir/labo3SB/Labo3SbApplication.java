package be.techni.ilir.labo3SB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Labo3SbApplication {

	public static void main(String[] args) {
		SpringApplication.run(Labo3SbApplication.class, args);
	}

}
